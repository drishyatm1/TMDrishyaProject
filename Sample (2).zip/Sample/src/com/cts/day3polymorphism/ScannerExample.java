/* Author: Drishya TM 
 * Date: 09/01/2020
 * Program : scanner */

package com.cts.day3polymorphism;

import java.util.Scanner;

public class ScannerExample {
	public static void main(String args[]) {
	Scanner scanner=new Scanner(System.in);
	
	System.out.println("enter the ip:");
	String ip=scanner.next();
	System.out.println(ip);
	// int newIp=Integer.parseInt(ip);
	scanner.useDelimiter("//.");
	 //System.out.println(+scanner.Delimiter());
	
	}

} 
