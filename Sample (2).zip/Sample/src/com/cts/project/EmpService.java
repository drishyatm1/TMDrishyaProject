/* Author: Drishya TM 
 * Date: 13/01/2020
 * Program : Project*/
package com.cts.project;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class EmpService {
	HashMap<Integer,Product> hmp=new HashMap();
	public EmpService() {
		hmp.put(1001, new Product(1001, "Tv", 5, 6000));
		hmp.put(1002, new Product(1002, "Furniture", 5, 8000));
		hmp.put(1003, new Product(1003, "Mobile", 5, 9800));
	}
	public int addProduct(Product pdt){
		hmp.put(pdt.getProdId(), pdt);
		//System.out.println(hmp);
		return pdt.getProdId();
	}
	
	public Product getProductById(int pdtId){
		Product data=hmp.containsKey(pdtId)?hmp.get(pdtId):null;
		//System.out.println(data);
		return data;
	}
	
	public HashMap<Integer,Product> getAllProducts(){
		return hmp;
	} 
}
