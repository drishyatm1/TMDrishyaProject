/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance and overridding, student example Student,DayScholar,Residential,test2  */
package com.cts.questions;

public class DayScholar extends Student {
	public void study() {
		
		System.out.println("study at home");
		super.study();  //control moves to parent class
	}
	public void breakfast() {
		System.out.println("had breakfast from home");
	}
	
	private void goBack() {
		System.out.println("go home by bus");
	}
	

}
