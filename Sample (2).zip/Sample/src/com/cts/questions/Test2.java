/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance and overridding, student example Student,DayScholar,Residential,test2  */
package com.cts.questions;

public class Test2 {
	
	public static void main(String args[]) {
		Student st=new Student();
		st.study();
		DayScholar ds=new DayScholar();
		ds.study();  //study in DayScholar overrides study in Student
		ds.walk();  //dayscholar inherits the walk method in student
	}

}
