/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : counter increment Employee,Manager,Test*/
package com.cts.questions;

public class Employee {
	static int counter=0;
	Employee(){
		counter++;
	}

	public void count() {
		System.out.println("object count="+counter);
	}
}
