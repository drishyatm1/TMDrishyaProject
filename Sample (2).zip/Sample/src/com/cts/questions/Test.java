/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : counter increment Employee,Manager,Test*/
package com.cts.questions;

public class Test {
	public static void main(String args[]) {
		
		Employee e=new Employee();
		Manager m=new Manager();
		Manager m2=new Manager();
		e.count();
	}

}
