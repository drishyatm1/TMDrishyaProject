/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : counter increment Employee,Manager,Test */
package com.cts.questions;

public class Manager extends Employee {
	
	

}
