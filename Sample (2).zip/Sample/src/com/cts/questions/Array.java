package com.cts.questions;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	}

}
