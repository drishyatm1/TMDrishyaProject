/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : list demo */
package com.cts.day4collection;
import java.util.*;
public class ListDemo {
public static void main(String args[]) {
	List l=new ArrayList();
	l.add("hii");
	l.add(10);
	l.add("hello");
	l.add(5);
	l.add(20);
	l.add(30);
	l.add(540);
	System.out.println("Data in the list:"+l);
	System.out.println("size="+l.size());

	
}
}
