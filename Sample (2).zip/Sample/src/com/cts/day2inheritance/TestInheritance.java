/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Main class class */
package com.cts.day2inheritance;

public class TestInheritance {
	
	public static void main(String args[]) {
		
		ScientificCalculator obj1=new ScientificCalculator();
		obj1.add(10,20);
		obj1.sub(60,20 );
		Calculator obj2=new Calculator();
		obj2.add(30,40);
		
	}

}
