/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Derived class */
package com.cts.day2inheritance;

public class Manager1 extends Employee1 {
	public int subordinatesNumber;

	
	
	@Override
	public String toString() {
		return "Manager1 [subordinatesNumber=" + subordinatesNumber + ", empId=" + empId + ", empName=" + empName + "]";
	}
	
	
	public static void main(String args[]) {
		Manager1 obj1=new Manager1();
		System.out.println(obj1);
	}

}
