/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Base class */

package com.cts.day2inheritance;

public class Calculator {
	
	public int result;
	
	
		
		public void add(int a, int b)
		{
			result=a+b;
			System.out.println("sum is"+result);
			
		}
		public void sub(int a,int b)
		{
			result=a-b;
			System.out.println("difference is"+result);
		}
	}


