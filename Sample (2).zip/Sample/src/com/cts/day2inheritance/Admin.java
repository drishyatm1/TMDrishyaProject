/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Derived class */
package com.cts.day2inheritance;

public class Admin extends Employee {

	public Admin() {
		
	}
	
	public Admin(int empId,String empName,String dept,String comp) 
	{
	super(empId,empName,dept,comp);	
	}
}
