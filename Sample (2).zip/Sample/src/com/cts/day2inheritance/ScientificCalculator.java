/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Derived class */
package com.cts.day2inheritance;

public class ScientificCalculator extends Calculator {
	public double a,result;
	
	public void sin() {
		/* result=sin(a); */
		System.out.println("sine value is");
	}
	
	public void cos() {
		System.out.println("cos value is");
	}

}
