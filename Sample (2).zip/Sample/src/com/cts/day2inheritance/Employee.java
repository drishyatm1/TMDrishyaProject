 /* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Base class */
package com.cts.day2inheritance;

public class Employee {
	private int empId;
	private String empName;
	private String dept;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getComp() {
		return comp;
	}
	public void setComp(String comp) {
		this.comp = comp;
	}
	private String comp;
	
	public void work() {
		System.out.println("from 9 to 6");
	}
	  public Employee(int empId,String empName,String dept,String comp) {
		  this.empId=empId;
		  this.empName=empName;
		  this.dept=dept;
		  this.comp=comp;
		  System.out.println("emp id is"+empId);
		  System.out.println("emp name is"+empName);
		  System.out.println("emp department is"+dept);
		  System.out.println("emp company is"+comp);
	  }
	  public Employee() {
		   
	  }


} 
