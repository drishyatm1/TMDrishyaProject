package com.cts.threadday7;

public class ThreadWait implements Runnable{
	
	@Override
	public synchronized void run() {
		String name = Thread.currentThread().getName();
		System.out.println(name);
		for (int i = 0; i <= 8; i++) {
			if (name.equals("wait")) {
				System.out.println(i+" waiting");
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				System.out.println(i+" notifying soon");
				if (i == 5)
					notify();
			}
		}

	}
	

}
