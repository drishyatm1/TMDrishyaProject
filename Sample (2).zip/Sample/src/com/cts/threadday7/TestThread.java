package com.cts.threadday7;

public class TestThread {
	
	public static void main(String[] args) {	
		
		ThreadWait obj2=new ThreadWait();
		Thread waitThread=new Thread(obj2);
		waitThread.setName("wait");
		Thread notThread=new Thread(obj2);
		notThread.setName("notify");
		waitThread.start();
		
		
		
		/*ThreadNotify obj1=new ThreadNotify();
		Thread notThread=new Thread(obj1);
		notThread.start();*/
	
		
		
	}

}
