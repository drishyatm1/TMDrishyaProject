/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : */
package com.cts.day5;

public class Main {
	
	public static void main(String args[])
	{
		System.out.println("enter the option");
		
		
		
	}
	

}
