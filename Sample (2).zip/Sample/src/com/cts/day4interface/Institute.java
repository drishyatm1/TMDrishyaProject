/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface eg1 */
package com.cts.day4interface;

class Institute  implements Icontract, Icontract2
{

	@Override
	public void java() {
		// TODO Auto-generated method stub
		System.out.println("java is implemented");
	}

	@Override
	public void j2ee() {
		// TODO Auto-generated method stub
		System.out.println("j2ee is implemented");
	}

	@Override
	public void spring() {
		// TODO Auto-generated method stub
		System.out.println("spring is implemented");
		
	}
 
}
