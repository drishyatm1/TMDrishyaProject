/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface eg1 */
package com.cts.day4interface;

public class TestInstitute {
	
	public static void main(String args[]) {
		Icontract i=null;
		i=new Institute();
		i.java();
		i.j2ee();
	/*	Icontract2 i2=new Institute();    //if Icontract dosent extend Icontract 2 , then a new reference must be created
		i2.spring();  */
		i.spring();
	}

}
