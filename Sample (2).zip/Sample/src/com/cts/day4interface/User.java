/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface */
package com.cts.day4interface;

public class User {

}
