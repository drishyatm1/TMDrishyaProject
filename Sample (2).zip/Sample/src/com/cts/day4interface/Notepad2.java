/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface eg2 */
package com.cts.day4interface;

interface Notepad2 {
	abstract void m4();

}
