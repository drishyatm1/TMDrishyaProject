/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface */
package com.cts.day4interface;

public class Test {
	public static void main(String args[])
	{
		Notepad r=new Os();
		r.m1();
		
		//Notepad2 r1=new Os(); no need since notepad extends notepad2
		r.m4();
	}

}
