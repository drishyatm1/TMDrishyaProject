/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface eg1 */
package com.cts.day4interface;

interface Icontract extends Icontract2 {

	abstract void java();
	abstract void j2ee();
}

