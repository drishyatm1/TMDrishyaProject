/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : interface eg2 */
package com.cts.day4interface;

class Os implements Notepad,Notepad2 {

	@Override
	public void m1() {
		System.out.println("m1 is accepted");
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m4() {
		// TODO Auto-generated method stub
		System.out.println("m4 is accepted");
	}

}
