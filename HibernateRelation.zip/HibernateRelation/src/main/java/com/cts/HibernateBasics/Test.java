package com.cts.HibernateBasics;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.HibernateModel.Cart;
import com.cts.HibernateModel.CartItem;

public class Test {

	public static void main(String args[]) {
		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		
		
		CartItem ci=new CartItem();
		ci.setCartItemId(200);
		ci.setQuantity(5);
		
		
		Cart cart=new Cart();
		cart.setCartId(100);
		cart.setDescription("First item");
		cart.setcI(ci);
		
		session.beginTransaction();
	
		session.save(ci);
		session.save(cart);
		session.getTransaction().commit();
		session.close();
		
		
		
		
		
		
		
	}
}
