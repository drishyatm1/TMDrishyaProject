package com.cts.HibernateModel;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Cart {
	
	@Id 
	@GeneratedValue
	private int cartId;
	private String description;
	
	@OneToOne
	private CartItem cI;
	
	public CartItem getcI() {
		return cI;
	}
	public void setcI(CartItem cI) {
		this.cI = cI;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Cart() {
		
	}

}
